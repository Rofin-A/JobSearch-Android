/**
 * @classname: GovtJobSearchServlet.Java
 * @author: Rofin A
 */
/*-----------------------------------------------------------------------------* 
*  Purpose: This class serves as the Servlet for jobsearch application. It 
   instantiates the model and calls appropriate methods from the model to fetch
   required job openings from US General Service Administration API.
*-------------------------------------------------------------------------------*/
package cmu.edu.randonis;

//---Import Libraries
//-------------------
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(name = "GovtJobSearchServlet", urlPatterns = {"/JobSearch/*"})
public class GovtJobSearchServlet extends HttpServlet {
    GovtJobSearchModel js  = null;
    // Initiate the servlet by instantiating the model
    @Override
    public void init() {
        js = new GovtJobSearchModel();
    }
    
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       String name = (request.getPathInfo()).substring(1);
       if(name!=null && !name.equals("*") ){
       //--Collect the param from the incoming url
       String[] param = collect_param(name);

       //Make an api call from model
       String resp = js.searchjobs(param);
       //--Write the response back to the connection port
          PrintWriter out = response.getWriter();
          out.println(resp);
       }
       
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }
    
/*---------------------------------------------------------------------------
 Mehtod- collect_param
 --- Signature:
     String name - The incoming parameters with the http req 
 --- Return: 
     String[] param - An array consisting of parameters
     param[0] - Job title
     param[1] - State code
 --- Purpose :
 This method extracts job title and state code to be searched for, from incoming
 HTTP request and returns it in a string array   
 ----------------------------------------------------------------------------*/
    public String[] collect_param(String name){
               //Separte the parameters 
       String[] inp_param = name.split(",");
       String par1 ="";
       String par2 ="";
       String[] param = new String[2];
       //--collect the parameters in order
       for(String par : inp_param){
           if(par.startsWith("job")){
              String[] temp = par.split("=");
              par1 = "query"+"="+temp[1];
           }
           else{
              String[] temp = par.split("=");
              par2 = "in"+"="+temp[1];
           }
               
       }
       param[0]=par1;
       param[1]=par2;
     return param;
    }
}
