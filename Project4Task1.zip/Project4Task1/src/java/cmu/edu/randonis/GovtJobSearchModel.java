/**
 * @classname: GovtJobSearchModel.Java
 * @author: Rofin A
 */
/*-----------------------------------------------------------------------------* 
*  Purpose: This class serves as the model for jobsearch application. It uses US
   General Service Administration API, to find a opening for a job in the given 
   state of interest.
*-------------------------------------------------------------------------------*/
package cmu.edu.randonis;

//----Import Libraries
//--------------------
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import javax.net.ssl.HttpsURLConnection;

//--- Class definition to hold response state
class Response {
    String value;     // To Hold the return patmeter
    //Getter
    public String getValue() {
        return value;
    }
    //Setter
    public void setValue(String value) {
        this.value = value;
    }
}

//---Model class definition
public class GovtJobSearchModel {
 /*---------------------------------------------------------------------------
 Mehtod- searchjobs
 --- Signature:
     String[] params - Parameters to be passed in API call (URL parameters)
 --- Return: 
     String representation JSON returned by the api call
 --- Purpose :
 This method invokes the API call and queries opening for the job searched in a 
 particular state.   
 ----------------------------------------------------------------------------*/
    public String searchjobs(String[] params) {
        //fabricate the parameters for api call
        String param = knit_params(params);
        // Frame the url for API call
        String url = "https://jobs.search.gov/jobs/search.json?" + param;
        System.out.println(url);
        //Instantial the response class to hold the state of response- return from api
        Response r = new Response();
        //Read the JSON output returned by the API call
        int status = fetch_result_4m_api(url, r);
        //--- In case the API call failed return the error message with appropriate error code
        if (status != 200) {
            System.out.println("Error fetching jobs;Error code " + status);
            r.setValue("");
            return r.value;
         //---Return the response(JSON)   
        } else {
            return r.value;
        }
    }

 /*---------------------------------------------------------------------------
 Mehtod- knit_params
 --- Signature:
     String[] params - Parameters to be passed in API call (URL parameters)
 --- Return: 
     String representation paramters in desired format to be appended to API's 
     URL for query
 --- Purpose :
 This method formulates the query paramter in desired parameter for API call   
 ----------------------------------------------------------------------------*/
   
    public String knit_params(String[] params) {
        //---Variable declaration
        String param = ""; //String variable to hold the parameters to be passed to url
        //loop through the parameters and concatenate them in a manner suitable for API call
        for (String arg : params) {
            if (param.isEmpty()) {
                param += arg;
            } else {
                param = param + "+" + arg;
            }
        }
        return param;
    }

/*---------------------------------------------------------------------------
 Mehtod- fetch_result_4m_api
 --- Signature:
     String URL - URL for API call
     Response R - State variable to hold the API respone
 --- Return: 
     Integer status representing the status of the API call. (200- success)
 --- Purpose :
 This method makes the API call to retrieve the job openings it retrieves the 
 String representation of the JSON call and sets it to the state variable
 ----------------------------------------------------------------------------*/
     
    public int fetch_result_4m_api(String url, Response r) {
        //----Variable declaration
       //-------------------------
        String feedback = "";
        int status = 0;
        try {
            URL urlstr = new URL(url);
            System.out.println(urlstr);
            
            //---Create an HTTPConnection
            HttpsURLConnection conn;
            conn = (HttpsURLConnection) urlstr.openConnection();
            //--Set HTTP connection method and retrieve the status code 
            conn.setRequestMethod("GET");
            //--Get the status code to check if the connection was successfull
            status = conn.getResponseCode();
            //-- if the connection is refused, return the status code
            if (status != 200) {
                return status;
            }

            //--- Get the input stream of the connection
            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String resp = "";
            //---Read the response and return 
            while ((resp = br.readLine()) != null) {
                feedback += resp;
            }
            //---Set the state variable
            r.setValue(feedback);
        } catch (MalformedURLException ex) {
            System.out.println("Error framing url: " + ex.getMessage());
        } catch (IOException ex) {
            System.out.println("IO Exceoption:" + ex.getMessage());
        }
        return status;
    }
}
