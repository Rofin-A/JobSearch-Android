/**
 * @classname: GSAJobSearch_Async_APISearch
 * @author: Rofin A
 */
/*-----------------------------------------------------------------------------*
*  Purpose: This class Serves as the model for the android application.This method
*  implements helper thread for the Job search functionality via third party api.
*  Once the job search is completed, it will callback the caterResults method of
*  of the controller which will in turn render the result in the frontendUI
*-------------------------------------------------------------------------------*/

package randonis.cmu.edu.gsajobsearch;


//---Import Libraries
import android.os.AsyncTask;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

public class GSAJobSearch_Async_APISearch {
    //=-- Variable declaration to hold reference of main activity
    JobSearchMainActivity js = null;

 /*---------------------------------------------------------------------------
 Mehtod- jSearch
 --- Signature:
     String Param - Search key and value pair (Job and State code)
     JobSearchMainActivity js - object reference to the controller
 --- Return:
 --- Purpose :
 This method spans the helper thread which will make a call to the servlet
 which in turn calls the 3rd party  GSA Job search portal with the parmaeters
 supplied. Upon completion of search, the results from the API is retrieved
 and passed as an argument to the callback method caterResults of controller
 which renders the results in the UI
 ----------------------------------------------------------------------------*/

public void jSearch(String param,JobSearchMainActivity js){
this.js = js;//Callback reference to the controller
//---Zeit link for the service
String url = "https://docker-ikteyhtgcq.now.sh/JobSearch/"+param;    //"https://docker-xkmtbaahzw.now.sh/JobSearch/"+param;
new AsyncJobSearch().execute(url);
}

    private class AsyncJobSearch extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... url) {   //helper thread for search
            return searchJob(url[0]);
        }
        @Override
        protected void onPostExecute(String s) {           //Callback method
          js.caterResults(s);
        }
        /*---------------------------------------------------------------------------
         Mehtod- searchJob
         --- Signature:
             String urlString- URL to the webservice (hosted on zeit)
         --- Return:
             String output - Feedback from the API (JSON)
         --- Purpose :
         This method is th helper thread which will make a call to the servlet
         which in turn calls the 3rd party  GSA Job search portal with the parmaeters
         supplied and retrieves the results from the API

         ----------------------------------------------------------------------------*/
        private String searchJob(String urlString){
            //---Variable declaration
            //-----------------------
            int status = 0;    // hold the status of the server call
            String output =""; // response returned by server

            try{
                //---Make an http request to invoke the get method of the server
                URL url = new URL(urlString);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");

                //--Read the status code to check if the call was sucessfull
                status = conn.getResponseCode();

                //---In case of any failure return error message with appropriate state
                if (status != 200) {
                    return null;
                }

                //--- Read the response from the http request
                String ret = "";
                // Read the feedback
                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                while((ret = br.readLine())!= null){
                    output += ret;
                }
                conn.disconnect();
                //---Set the state variable

            } catch (MalformedURLException ex) {
                System.out.println("Error framing the URL "+ex.getMessage());
                return null;
            } catch (IOException ex) {
                System.out.println("Error connecting to Server "+ex.getMessage());
                return null;
            }
            //--- Return the status
            System.out.println(output);
            return output;
        }
    }

}


