/**
 * classname: JobSearchMainActivity
 * author: Rofin A
  -----------------------------------------------------------------------------*
 *  Purpose: This class Serves as the controller for the android application.This method
 *  makes call to the model to fetch the jobs openings from 3rd party API and upon
 *  completion of search the model will callback the caterResults method
 *  which will render the result in the frontendUI
 *-------------------------------------------------------------------------------*/

package randonis.cmu.edu.gsajobsearch;
//--Import Libraries
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class JobSearchMainActivity extends AppCompatActivity {
    //---Capture the object reference for callback
    final JobSearchMainActivity ref = this;

    //---On create method which will be executed once the APP is invoked
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_job_search_main);

        //-- Get the reference of the the search button
        //---------------------------------------------
        ImageButton search = (ImageButton)findViewById(R.id.searchButton);
        //--Add a listener to the button
        search.setOnClickListener(new View.OnClickListener(){
            public void onClick(View viewParam) {
                EditText job = (EditText)findViewById(R.id.jobTitleJ);
                EditText state = (EditText)findViewById(R.id.state);

                //--Check if the input parameters are filled if not show error message
                //--------------------------------------------------------------------
                if( TextUtils.isEmpty(job.getText())){job.setError("Job Title is required!");}
                else if( TextUtils.isEmpty(state.getText())){state.setError("State is required!");}

                //--If the input parameters are supplied call the search method in helper thread
                //-- Asynchronous mode - to search GSA job postings
                //------------------------------------------------------------------------------
                else{
                    String jobTitle = job.getText().toString();
                    String stateCode = state.getText().toString();
                    String urlParam = "job"+"="+jobTitle+","+"state"+"="+stateCode;
                    GSAJobSearch_Async_APISearch doSearch = new GSAJobSearch_Async_APISearch();
                    doSearch.jSearch(urlParam,ref);
                }
            }});
    }

/*--------------------------------------------------------------------------------------------------
 Method- caterResults
 --- Signature:
     String Result- Response of the Asynchronous API call
 --- Return:
 --- Purpose :
 This method serves as the callback method for the spanned helper thread. Upon completion
 of execution the helper thread calls this method and passes the result of API call as the
 argument. This method will capture the arguments and cater the results in UI (in tableview)
 -------------------------------------------------------------------------------------------------*/

    public void caterResults(String result){
        try {
            JSONArray job_det = new JSONArray(result);

                //Get the table layout reference
                TableLayout tv=(TableLayout) findViewById(R.id.resultTab);
                tv.removeAllViewsInLayout();
                tv.setVisibility(View.VISIBLE);

            if(job_det.length() == 0){Toast.makeText(this, "No records found!Please check the input and try again", Toast.LENGTH_LONG).show();}
//---For each entry in JSONArray, create a row, add a text view and bind it to the table layout (this idea has been adopted from Internet)
            for (int i=0;i<job_det.length();i++) {
                //---for alternating rows set a color to implement zebra pattern
                int col = Color.WHITE;//Color.rgb(51,181,229); //
                if(i%2==0){col = Color.rgb(150,160,170);} //125,249,255
                //else{col = Color.WHITE;}
                JSONObject job_val = job_det.getJSONObject(i);
                TableRow tr1=new TableRow(ref);
                TableRow tr2=new TableRow(ref);
                TableRow tr3=new TableRow(ref);
                TableRow tr4=new TableRow(ref);

                //----Position title will be the id and the header
                add_row(tv,tr1,"Position:",job_val.get("position_title").toString(),col);
                //----Organization
                add_row(tv,tr2,"Org:",job_val.get("organization_name").toString(),col);
                //----minimum Salary
                add_row(tv,tr3,"Salary (min):",job_val.get("minimum").toString(),col);
                //----URL
                add_row(tv,tr4,"Application URL:",job_val.get("url").toString(),col);

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

/*--------------------------------------------------------------------------------------------------
 Method- caterResults
 --- Signature:
     TableLayout tv - Reference for the table layout
     TableRow tr - Instance of the table row to be added
     String label - row description
     String content - Content (field value)
     int col - color code for the row (For zebra pattern)
 --- Return:
 --- Purpose :
 This method incorporates the instance of table row into the tableLayout
 -------------------------------------------------------------------------------------------------*/

    private void add_row(TableLayout tv,TableRow tr,String label,String content,int col){
        //---Create a text view for label and populate it - Field name
        TextView posLabel = new TextView(ref);
        posLabel.setText(label);
        posLabel.setTypeface(null, Typeface.BOLD);
        posLabel.setWidth(250);
        tr.addView(posLabel);

        //---Create a text view for content and populate it - Field value
        TextView pos = new TextView(ref);
        pos.setText(content);
        pos.setTextSize(12);
        pos.setWidth(800);
        pos.setTextIsSelectable(true);

        //--Add the textview to row and the row to table layout
        tr.addView(pos);
        tr.setBackgroundColor(Color.CYAN);
        tr.setBackgroundColor(col);
        tv.addView(tr);//

    }
}
